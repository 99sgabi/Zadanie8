package pl.edu.pb.onlinelibraryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class BookDetailActivity extends AppCompatActivity {

    private TextView bookTitleTextView;
    private TextView bookAuthorTextView;
    private ImageView bookCoverImageView;
    private static final String IMAGE_URL_BASE = "http://covers.openlibrary.org/b/id/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        bookAuthorTextView = findViewById(R.id.details_book_author);
        bookTitleTextView = findViewById(R.id.details_book_title);
        bookCoverImageView = findViewById(R.id.details_book_cover);

        Intent intent = getIntent();
        Book book = (Book)intent.getSerializableExtra(MainActivity.KEY_BOOK_TO_SHOW);

        bookAuthorTextView.setText(book.getAuthors().get(0));
        bookTitleTextView.setText(book.getTitle());
        if(book.getCover() != null)
            Picasso.with(this)
                    .load( IMAGE_URL_BASE + book.getCover() + "-L.jpg")
                    .placeholder(R.drawable.ic_baseline_book_24).into(bookCoverImageView);
        else
            bookCoverImageView.setImageResource(R.drawable.ic_baseline_book_24);
    }
}