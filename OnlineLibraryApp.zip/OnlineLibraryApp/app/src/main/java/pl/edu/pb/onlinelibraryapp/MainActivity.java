package pl.edu.pb.onlinelibraryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    public final static String KEY_BOOK_TO_SHOW = "Book key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(savedInstanceState != null)
        {

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.book_menu,menu);

        MenuItem searchItem = menu.findItem(R.id.menu_item_search);
        final SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                fetchBooksData(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.menu_item_clear:
                RecyclerView recyclerView = findViewById(R.id.recyclerview);
                ((BookAdapter)recyclerView.getAdapter()).setBooks(new ArrayList<Book>());
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void fetchBooksData(String query)
    {
        String finalQuery = prepareQuery(query);
        BookService bookService = RetrofitInstance.getRetrofitInstance().create(BookService.class);

        Call<BookContainer> bookApiCall = bookService.findBooks(finalQuery);
        bookApiCall.enqueue(new Callback<BookContainer>() {
            @Override
            public void onResponse(Call<BookContainer> call, Response<BookContainer> response) {
                setupBookListView(response.body().getBookList());
            }

            @Override
            public void onFailure(Call<BookContainer> call, Throwable t) {
                Snackbar.make(findViewById(R.id.main_view), getString(R.string.went_wrong_message),
                        Snackbar.LENGTH_LONG).show();
            }
        });
    }

    private void setupBookListView(List<Book> books)
    {
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        final BookAdapter adapter = new BookAdapter();
        adapter.setBooks(books);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private boolean checkNullOrEmpty(String text)
    {
        return text!=null && !TextUtils.isEmpty(text);
    }

    private String prepareQuery(String query)
    {
        String[] queryParts = query.split("\\s+");
        return TextUtils.join("+", queryParts);
    }

    private class BookHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        private static final String IMAGE_URL_BASE = "http://covers.openlibrary.org/b/id/";
        private TextView bookTitleTextView;
        private TextView bookAuthorTextView;
        private ImageView bookCover;
        private Book book;

        public BookHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.book_list_item, parent, false));

            bookAuthorTextView = itemView.findViewById(R.id.book_author);
            bookTitleTextView = itemView.findViewById(R.id.book_title);
            bookCover = itemView.findViewById(R.id.img_cover);

            itemView.setOnClickListener(this);
        }

        public void bind(Book book)
        {
            this.book = book;
            if(book != null && checkNullOrEmpty(book.getTitle()) && book.getAuthors() != null)
            {
                bookTitleTextView.setText(book.getTitle());
                bookAuthorTextView.setText(TextUtils.join(", ", book.getAuthors()));
                if(book.getCover() != null)
                    Picasso.with(itemView.getContext())
                        .load(IMAGE_URL_BASE + book.getCover() + "-S.jpg")
                        .placeholder(R.drawable.ic_baseline_book_24).into(bookCover);
                else
                    bookCover.setImageResource(R.drawable.ic_baseline_book_24);
            }

        }

        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, BookDetailActivity.class);
            intent.putExtra(KEY_BOOK_TO_SHOW,book);
            startActivity(intent);
        }
    }

    private class BookAdapter extends RecyclerView.Adapter<BookHolder>
    {
        List<Book> books;

        @NonNull
        @Override
        public BookHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
            return new BookHolder(layoutInflater, parent);
        }

        void setBooks(List<Book> books)
        {
            this.books = books;
            notifyDataSetChanged();
        }

        @Override
        public void onBindViewHolder(@NonNull BookHolder holder, int position) {
            if(books != null){
                Book book = books.get(position);
                holder.bind(book);
            }
            else
                Log.d("MainActivity", "No books");
        }

        @Override
        public int getItemCount() {
            if(books == null)
                return 0;
            else
                return books.size();
        }
    }
}